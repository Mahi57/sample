<?php
include_once "includes/dbconfig.php";
$token=$_GET['token'];

    $ref="contact/";
    $postdata = $database->getReference($ref)->getChild($token)->remove();
    if($postdata)
    {
        echo "Data Deleted";
        header('Location:fetch.php');
    }
    else
    {
        echo "Data deletion failed";
        header('Location:fetch.php');
    }


    ?>