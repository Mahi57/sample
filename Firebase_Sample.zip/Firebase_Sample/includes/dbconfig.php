<?php
   require __DIR__.'/vendor/autoload.php';

   use Kreait\Firebase\Factory;
   use Kreait\Firebase\ServiceAccount;

   // This assumes that you have placed the Firebase credentials in the same directory
   // as this PHP file.
   $serviceAccount = ServiceAccount::fromJsonFile(__DIR__ . '/sample-79a1d-firebase-adminsdk-4mhd4-2ac69b5dc6.json');
   $firebase = (new Factory)
      ->withServiceAccount($serviceAccount)
      ->withDatabaseUri('https://sample-79a1d-default-rtdb.firebaseio.com')
      ->create();
      
   $database = $firebase->getDatabase();
?>