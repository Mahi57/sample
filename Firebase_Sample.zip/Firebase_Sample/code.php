<?php
include_once "includes/dbconfig.php";
if(isset($_POST['submit']))
{
    $name=$_POST['name'];
    $email=$_POST['email'];
    $phone=$_POST['phone'];
    $data= [
        'name' => $name,
        'email' => $email,
        'phone' => $phone
    ];

    $ref="contact/";
    $postdata = $database->getReference($ref)->push($data);
    if($postdata)
    {
        echo "Data Inserted";
    }
    else
    {
        echo "Data insertion failed";
    }
}









if(isset($_POST['update']))
{
    $name=$_POST['name'];
    $email=$_POST['email'];
    $phone=$_POST['phone'];
    $token=$_POST['token'];
    $data= [
        'name' => $name,
        'email' => $email,
        'phone' => $phone
    ];

    $ref="contact/";
    $postdata = $database->getReference($ref)->getChild($token)->update($data);
    if($postdata)
    {
        echo "Data Updated";
        header('Location:fetch.php');
    }
    else
    {
        echo "Data Updation failed";
        header('Location:fetch.php');
    }
}




?>